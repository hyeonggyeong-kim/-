# Security Policy

## Supported Versions

We support only latest current version of FastNetMon. We do not issue security fixes for older versions. To address any security issues you need to update to latest supported version. 

Debian, Ubuntu, Fedora, FreeBSD packages in their official repositories have their own security policies. 

## Reporting a Vulnerability

To report vulnerability please use this email pavel.odintsov@gmail.com We guarantee initial feedback in 48 hours. 
