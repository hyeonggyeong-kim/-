#include "traffic_data.pb.h"

bool write_simple_packet_to_protobuf(const simple_packet_t& packet, TrafficData& traffic_data);
