#ifndef EXAMPLE_PLUGIN_H
#define EXAMPLE_PLUGIN_H

#include "../fastnetmon_types.hpp"

// This function should be implemented in plugin
void start_example_collection(process_packet_pointer func_ptr);

#endif
