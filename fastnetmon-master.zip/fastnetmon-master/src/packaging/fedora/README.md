You can find up to date SPECs for Fedora on [upstream page](https://src.fedoraproject.org/rpms/fastnetmon)
