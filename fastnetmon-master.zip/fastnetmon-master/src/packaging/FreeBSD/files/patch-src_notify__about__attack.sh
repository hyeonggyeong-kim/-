--- src/notify_about_attack.sh.orig	2023-03-06 10:33:26 UTC
+++ src/notify_about_attack.sh
@@ -1,4 +1,4 @@
-#!/usr/bin/env bash
+#!/bin/sh
 
 #
 # Hello, lovely FastNetMon customer. I'm really happy to see you here
