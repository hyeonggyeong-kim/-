#include "../fastnetmon_types.hpp"
#include <string>

void exabgp_ban_manage(const std::string& action, const std::string& ip_as_string, const subnet_cidr_mask_t& customer_network);
