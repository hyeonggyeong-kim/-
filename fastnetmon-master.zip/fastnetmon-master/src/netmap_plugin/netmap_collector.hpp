#ifndef NETMAP_PLUGIN_H
#define NETMAP_PLUGIN_H

#include "../fastnetmon_types.hpp"

void start_netmap_collection(process_packet_pointer func_ptr);

#endif
